
export class Employee {
    empId: number;
    name: string;
    tier: number;
    leavesTaken: number;
    totalExperience: number;
    salary: number;
    constructor() {
    }
}
